#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::validateInput(int &value1, int &value2, int &base)
{
    // Проверка системы счисления (допустимые: 2, 4, 8, 10, 16)
    bool baseOk;
    base = ui->lineEdit_system->text().toInt(&baseOk);
    if(!baseOk || (base != 2 && base != 4 && base != 8 && base != 10 && base != 16)) {
        ui->label_result_value->setText("Ошибка: система счисления должна быть 2,4,8,10 или 16");
        return false;
    }

    // Проверка первого числа
    QString num1 = ui->lineEdit_value_1->text();
    value1 = num1.toInt(&baseOk, base);
    if(!baseOk || num1.isEmpty()) {
        ui->label_result_value->setText("Ошибка: некорректное первое число");
        return false;
    }

    // Проверка второго числа
    QString num2 = ui->lineEdit_value_2->text();
    value2 = num2.toInt(&baseOk, base);
    if(!baseOk || num2.isEmpty()) {
        ui->label_result_value->setText("Ошибка: некорректное второе число");
        return false;
    }

    return true;
}

void MainWindow::showResult(int result, int base)
{
    ui->label_result_value->setText(QString::number(result, base).toUpper());
}

void MainWindow::on_pushButton_1_clicked() // Сложение
{
    int value1, value2, base;
    if(!validateInput(value1, value2, base)) return;
    showResult(value1 + value2, base);
}

void MainWindow::on_pushButton_2_clicked() // Вычитание
{
    int value1, value2, base;
    if(!validateInput(value1, value2, base)) return;
    showResult(value2 - value1, base);
}

void MainWindow::on_pushButton_3_clicked() // Умножение
{
    int value1, value2, base;
    if(!validateInput(value1, value2, base)) return;
    showResult(value1 * value2, base);
}

void MainWindow::on_pushButton_4_clicked() // Деление
{
    int value1, value2, base;
    if(!validateInput(value1, value2, base)) return;

    if(value2 == 0) {
        ui->label_result_value->setText("Ошибка: деление на ноль");
        return;
    }

    if(base == 10) {
        double result = static_cast<double>(value2) / value1;
        ui->label_result_value->setText(QString::number(result, 'f', 4));
    } else {
        showResult(value2 / value1, base);
    }
}
